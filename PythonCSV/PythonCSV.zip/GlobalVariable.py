# -*- coding: utf-8 -*-
# coding: utf-8



StringTab = '    '
doubleTab = StringTab + StringTab
ItemNums = 0			# 数据总项列数量.
CSVData = ""			# CSV字符串全数据.
ItemName = ''			# 数据表所有列名字.
ItemType = '' 			# 数据表所有列类型.
ItemRows = ''			# 数据表CSV行数.

CSVInPath = '' 			# 测试用 CSV文件的绝对路径.
ProtoOutPath = '' 		# 输出Proto路径.
ProtoDataPath = ''		# Proto Data数据
CsharpOutPath = ''		# 输出Charp路径
PythonClassOutPath = ''	# 输出Python解释类路径


ProtoGenEXE = ''		# CS类生成执行文件路径
ProtocEXE = ''			# Python类生成执行文件路径